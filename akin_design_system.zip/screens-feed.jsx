// Akin — Feed, Categories, Filters
const { T, Ico, Spice, Ident, CategoryTag, Capacity, Btn, TabBar, TopBar, PostCard, POSTS, CATEGORIES } = window;

function ScreenFeed() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ padding: '20px 22px 14px', borderBottom: `1px solid ${T.hairline}` }}>
        <div style={{ fontFamily: T.serif, fontSize: 30, lineHeight: 1.1, letterSpacing: -0.5, color: T.ink }}>akin</div>
        <div style={{ display:'flex', alignItems:'center', gap: 18, marginTop: 14, fontFamily: T.sans, fontSize: 13.5, color: T.inkMute }}>
          <span style={{ color: T.ink, fontWeight: 500, borderBottom: `1.5px solid ${T.ink}`, paddingBottom: 4 }}>All</span>
          <span style={{ paddingBottom: 4 }}>Categories</span>
          <span style={{ flex: 1 }}/>
          <span style={{ display:'inline-flex', alignItems:'center', gap: 4 }}>{Ico.sort(15)} Recent</span>
        </div>
      </div>
      <div style={{ flex: 1, overflow:'auto' }}>
        {POSTS.map((p,i) => <PostCard key={p.id} post={p} last={i === POSTS.length-1}/>)}
      </div>
      <TabBar active="read"/>
    </div>
  );
}

function ScreenCategories() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ padding: '20px 22px 14px', borderBottom: `1px solid ${T.hairline}` }}>
        <div style={{ fontFamily: T.serif, fontSize: 30, lineHeight: 1.1, letterSpacing: -0.5, color: T.ink }}>Categories</div>
        <div style={{ display:'flex', alignItems:'center', gap: 18, marginTop: 14, fontFamily: T.sans, fontSize: 13.5, color: T.inkMute }}>
          <span style={{ paddingBottom: 4 }}>All</span>
          <span style={{ color: T.ink, fontWeight: 500, borderBottom: `1.5px solid ${T.ink}`, paddingBottom: 4 }}>Categories</span>
        </div>
      </div>
      <div style={{ flex: 1, overflow:'auto' }}>
        {CATEGORIES.map((c, i) => (
          <div key={c.id} style={{
            padding: '20px 22px',
            borderBottom: i === CATEGORIES.length-1 ? 'none' : `1px solid ${T.hairline}`,
            display:'flex', alignItems:'center', gap: 14,
          }}>
            <div style={{ flex:1 }}>
              <div style={{ fontFamily: T.serif, fontSize: 19, color: T.ink, letterSpacing: -0.2, marginBottom: 4 }}>{c.name}</div>
              <div style={{ fontFamily: T.sans, fontSize: 13, color: T.inkMute, lineHeight: 1.45 }}>{c.desc}</div>
            </div>
            <div style={{ textAlign:'right' }}>
              <div style={{ fontFamily: T.mono, fontSize: 13, color: T.inkSoft }}>{c.count}</div>
              <div style={{ fontFamily: T.sans, fontSize: 11, color: T.inkFaint, letterSpacing: 0.3, textTransform:'uppercase', marginTop: 2 }}>open</div>
            </div>
            <span style={{ color: T.inkFaint }}>{Ico.chev(14)}</span>
          </div>
        ))}
      </div>
      <TabBar active="read"/>
    </div>
  );
}

function ScreenCategoryDetail() {
  const cat = CATEGORIES[5]; // Decode This!
  const items = POSTS.filter(p => p.category.includes('DECODE') || true).slice(0,4);
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left={Ico.back(20)} title=""/>
      <div style={{ padding: '8px 22px 18px', borderBottom: `1px solid ${T.hairline}` }}>
        <div style={{ fontFamily: T.mono, fontSize: 11, color: T.inkMute, letterSpacing: 1.4, textTransform:'uppercase', marginBottom: 8 }}>Category</div>
        <div style={{ fontFamily: T.serif, fontSize: 32, lineHeight: 1.05, letterSpacing: -0.5, color: T.ink, marginBottom: 8 }}>Decode This!</div>
        <div style={{ fontFamily: T.sans, fontSize: 14, color: T.inkSoft, lineHeight: 1.5 }}>What did they actually mean. Bring the text, get four reads on it.</div>
        <div style={{ display:'flex', gap: 16, marginTop: 16, fontFamily: T.sans, fontSize: 12.5, color: T.inkMute }}>
          <span style={{ display:'inline-flex', alignItems:'center', gap: 5 }}>{Ico.filter(13)} 3+ flames</span>
          <span style={{ display:'inline-flex', alignItems:'center', gap: 5 }}>{Ico.sort(13)} Most comments</span>
        </div>
      </div>
      <div style={{ flex:1, overflow:'auto' }}>
        {items.map((p,i)=> <PostCard key={p.id} post={p} last={i===items.length-1}/>)}
      </div>
      <TabBar active="read"/>
    </div>
  );
}

function ScreenFilterSheet() {
  return (
    <div style={{ width: 390, height: 844, background: 'rgba(35,31,33,0.4)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ flex:1 }}/>
      <div style={{ background: T.bg, borderRadius: '20px 20px 0 0', padding: '14px 0 36px' }}>
        <div style={{ width: 36, height: 4, background: T.divider, borderRadius: 2, margin: '0 auto 18px' }}/>
        <div style={{ padding: '0 24px 18px', borderBottom: `1px solid ${T.hairline}` }}>
          <div style={{ fontFamily: T.serif, fontSize: 22, color: T.ink, letterSpacing: -0.3 }}>Sort & filter</div>
        </div>
        <div style={{ padding: '18px 24px 8px' }}>
          <div style={{ fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase', marginBottom: 10 }}>Sort by</div>
          {['Most recent','Most comments','Highest spice'].map((label, i) => (
            <div key={label} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding: '12px 0', borderBottom: i===2 ? 'none' : `1px solid ${T.hairline}` }}>
              <span style={{ fontFamily: T.sans, fontSize: 15, color: T.ink }}>{label}</span>
              {i === 0 && <span style={{ color: T.ink }}>{Ico.check(16)}</span>}
            </div>
          ))}
        </div>
        <div style={{ padding: '18px 24px 0' }}>
          <div style={{ fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase', marginBottom: 12 }}>Minimum spice</div>
          <div style={{ display:'flex', gap: 8 }}>
            {[0,1,2,3,4,5].map(n => (
              <div key={n} style={{
                flex:1, padding: '10px 0', textAlign:'center',
                border: `1px solid ${n===0 ? T.ink : T.divider}`,
                borderRadius: 4,
                fontFamily: T.sans, fontSize: 13, fontWeight: n===0?500:400,
                color: n===0 ? T.ink : T.inkMute,
                background: n===0 ? T.surface : 'transparent',
              }}>{n === 0 ? 'Any' : n+'+'}</div>
            ))}
          </div>
        </div>
        <div style={{ padding: '24px 24px 0' }}>
          <Btn kind="primary" size="lg" full>Apply</Btn>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ScreenFeed, ScreenCategories, ScreenCategoryDetail, ScreenFilterSheet });
