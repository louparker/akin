// Akin — sample data
const POSTS = [
  {
    id:'p1', category:'VENT SPACE', time:'12 min ago',
    title:"He texted 'wyd' at 11pm. Three weeks of 'good morning beautiful' and now wyd at 11pm.",
    excerpt:"I'm not even mad about the obvious thing. I'm mad that I felt it shift before he sent it. Like I knew. And I still answered the first round of texts like everything was fine because I wanted to be wrong.",
    op:'AmberLark82', participants: 3, spice: 4,
  },
  {
    id:'p2', category:'IS THIS NORMAL', time:'47 min ago',
    title:"Third date ended at her door with a hug and 'this was nice.' What is the read here.",
    excerpt:"Genuinely asking. We had a great time. I thought we did. She replied to my 'home safe?' text with a thumbs up and that was 14 hours ago. Am I being dramatic.",
    op:'QuietRiver14', participants: 2, spice: 2,
  },
  {
    id:'p3', category:'DECODE THIS', time:'1 hr ago',
    title:'"I\'m not really looking for anything serious right now but you\'re different"',
    excerpt:"Tell me honestly. Is this ever true. I want it to be true. I have wanted it to be true four times now and I'm starting to think I'm the variable.",
    op:'PlumOrchard07', participants: 4, spice: 5,
  },
  {
    id:'p4', category:'STORY TIME', time:'2 hr ago',
    title:'The man brought a printed list of his five-year goals to date two.',
    excerpt:"Laminated. Asked me where I saw myself fitting in by year three. I am still thinking about it. I do not know if I am charmed or running.",
    op:'CedarOwl33', participants: 3, spice: 3,
  },
  {
    id:'p5', category:'GOOD VIBES', time:'4 hr ago',
    title:'A small good thing: he asked what kind of tired I was before suggesting we move the date.',
    excerpt:"Three years of this and that's the first time. I want to put it on a shelf where I can see it.",
    op:'RoanFinch21', participants: 1, spice: 0,
  },
  {
    id:'p6', category:'HYPOTHETICALLY', time:'6 hr ago',
    title:'If you\'ve been single 6+ years — what changed when it finally happened?',
    excerpt:"Not the meet-cute. The internal thing. What did you stop doing or start doing right before. I think I am close but I keep getting in my own way.",
    op:'AshenWillow49', participants: 4, spice: 2,
  },
];

const CATEGORIES = [
  { id:'vent',     name:'Vent Space',          desc:'Just need to put it somewhere.',           count: 142 },
  { id:'feels',    name:'All The Feels',       desc:'For when the feeling is the whole post.',  count: 88 },
  { id:'advice',   name:'Advice Needed',       desc:'You ask. They answer. Honestly.',          count: 211 },
  { id:'wonder',   name:'Just Wondering',      desc:'Low-stakes questions worth asking.',       count: 67 },
  { id:'story',    name:'Story Time',          desc:'Things that happened. Tell us.',           count: 156 },
  { id:'decode',   name:'Decode This!',        desc:"What did they actually mean.",             count: 198 },
  { id:'aitoo',    name:'AITOO / Reality Check',desc:"Was I the problem. Be honest.",           count: 102 },
  { id:'hypo',     name:'Hypothetically Speaking…', desc:'Thought experiments. No wrong answer.', count: 54 },
  { id:'good',     name:'Good Vibes Only',     desc:'Small good things. Real ones.',            count: 73 },
];

const COMMENTS = [
  { id:'c1', author:'QuietRiver14', text:"The 11pm wyd is the part. The shift you felt was real. You can know something before it has happened to you yet. I'm sorry.", time:'8 min ago' },
  { id:'c2', author:'PlumOrchard07', text:"Different gender, similar pattern from my side once: it usually meant I'd already mentally exited and was looking for the easy ramp out. Not always. But often. The good morning texts were the script, not the feeling.", time:'4 min ago' },
  { id:'c3', author:'AmberLark82', text:"Reading this is hard but useful. Thank you for being plain about it. I think I knew.", time:'just now', isOp: true },
];

window.POSTS = POSTS;
window.CATEGORIES = CATEGORIES;
window.COMMENTS = COMMENTS;
