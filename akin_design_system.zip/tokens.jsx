// Akin design tokens — single source of truth
const T = {
  // Surfaces — warm, not pure white
  bg:        '#EFEAE2',  // bone — primary surface
  surface:   '#F6F2EB',  // raised — cards
  paper:     '#FBF8F3',  // input fields, modals
  divider:   'rgba(35,31,33,0.10)',
  hairline:  'rgba(35,31,33,0.06)',

  // Ink — Shadow Grey
  ink:       '#231F21',
  inkSoft:   '#3F3A3B',
  inkMute:   '#6A6464',
  inkFaint:  '#9C9692',

  // Accents
  teal:      '#2C4D55',  // primary accent — Dark Slate Grey, deepened
  tealSoft:  '#5C7C84',
  tealTint:  'rgba(44,77,85,0.08)',
  rust:      '#B54C26',  // spice / flame — used sparingly
  rustSoft:  'rgba(181,76,38,0.12)',
  blue:      '#788BFF',  // single utility tint — used for "you" markers
  blueSoft:  'rgba(120,139,255,0.10)',

  // Type
  serif: '"Source Serif 4", "Source Serif Pro", Georgia, serif',
  sans:  'Inter, -apple-system, "SF Pro Text", system-ui, sans-serif',
  mono:  '"JetBrains Mono", ui-monospace, "SF Mono", Menlo, monospace',
};
window.T = T;
