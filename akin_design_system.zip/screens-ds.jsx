// Akin — Design System screens
const { T, Ico, Spice, Ident, CategoryTag, Capacity, Btn } = window;

function DSPage() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, fontFamily: T.sans, color: T.ink, overflow:'hidden', display:'flex', flexDirection:'column' }}>
      <div style={{ padding: '40px 28px 28px', borderBottom: `1px solid ${T.hairline}` }}>
        <div style={{ fontFamily: T.mono, fontSize: 11, color: T.inkMute, letterSpacing: 1, textTransform:'uppercase', marginBottom: 14 }}>Akin · v1.0 · MVP</div>
        <div style={{ fontFamily: T.serif, fontSize: 36, lineHeight: 1.05, letterSpacing: -0.6, color: T.ink, marginBottom: 12 }}>A quieter place<br/>to talk about dating.</div>
        <div style={{ fontSize: 14, color: T.inkSoft, lineHeight: 1.5, maxWidth: 320 }}>Anonymous text-only conversations, capped at four people. The cap is the point.</div>
      </div>

      <div style={{ flex:1, overflow:'auto', padding: '20px 28px 40px' }}>
        <DSSection title="Color">
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 8 }}>
            <Sw name="Bone" hex="#EFEAE2" bg={T.bg} ink={T.ink} note="surface"/>
            <Sw name="Paper" hex="#FBF8F3" bg={T.paper} ink={T.ink} note="input"/>
            <Sw name="Shadow" hex="#231F21" bg={T.ink} ink={T.bg} note="ink"/>
            <Sw name="Ink soft" hex="#3F3A3B" bg={T.inkSoft} ink={T.bg} note="body"/>
            <Sw name="Slate" hex="#2C4D55" bg={T.teal} ink={T.bg} note="accent"/>
            <Sw name="Rust" hex="#B54C26" bg={T.rust} ink={T.bg} note="spice only"/>
          </div>
          <div style={{ fontSize: 12, color: T.inkMute, marginTop: 12, lineHeight: 1.5 }}>
            <em style={{ fontFamily: T.serif }}>No saturated brand colours.</em> Rust is reserved for the spice flames. Slate is the only accent on interactive surfaces. Hearts, pinks, and reds are not in the system.
          </div>
        </DSSection>

        <DSSection title="Type">
          <TypeRow font={T.serif} weight={400} size={28} sample="Source Serif 4 — display" name="Display / 28-32"/>
          <TypeRow font={T.serif} weight={400} size={20} sample="Headlines for posts and rooms" name="Title / 19-22"/>
          <TypeRow font={T.sans} weight={500} size={15} sample="UI labels and primary actions" name="Label / 14-16 · 500"/>
          <TypeRow font={T.sans} weight={400} size={14} sample="Body copy reads like a thoughtful friend." name="Body / 14"/>
          <TypeRow font={T.mono} weight={400} size={12} sample="AmberLark82 · CrimsonFox14" name="Identifier / mono 12"/>
        </DSSection>

        <DSSection title="Identifiers">
          <div style={{ display:'flex', flexDirection:'column', gap: 8 }}>
            <Ident name="AmberLark82"/>
            <Ident name="CedarOwl33"/>
            <Ident name="RoanFinch21" you/>
          </div>
          <div style={{ fontSize: 12, color: T.inkMute, marginTop: 10, lineHeight: 1.5 }}>
            [Adjective][Noun][2-4 digits]. The same row chrome for everyone. No avatars, no rings, no segmentation by gender, age, or orientation.
          </div>
        </DSSection>

        <DSSection title="Spice · 1—5 flames">
          <div style={{ display:'flex', flexDirection:'column', gap: 6 }}>
            {[1,2,3,4,5].map(n => (
              <div key={n} style={{ display:'flex', alignItems:'center', gap: 14 }}>
                <Spice level={n} size={14}/>
                <span style={{ fontFamily: T.sans, fontSize: 13, color: T.inkSoft }}>{['Soft','Mild','Sharp','Hot','Scorched'][n-1]}</span>
              </div>
            ))}
          </div>
        </DSSection>

        <DSSection title="Capacity · max 4">
          <div style={{ display:'flex', alignItems:'center', gap: 14, marginBottom: 8 }}>
            <Capacity filled={1}/>
            <span style={{ fontSize: 12, color: T.inkMute }}>1/4 · open</span>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap: 14, marginBottom: 8 }}>
            <Capacity filled={3}/>
            <span style={{ fontSize: 12, color: T.inkMute }}>3/4 · one seat left</span>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap: 14 }}>
            <Capacity filled={4}/>
            <span style={{ fontSize: 12, color: T.inkMute }}>4/4 · full · read-only</span>
          </div>
        </DSSection>

        <DSSection title="Buttons">
          <div style={{ display:'flex', flexDirection:'column', gap: 10 }}>
            <Btn kind="primary" full>Post it</Btn>
            <Btn kind="secondary" full>Maybe later</Btn>
            <div style={{ display:'flex', gap: 8 }}>
              <Btn kind="ghost" size="sm">Cancel</Btn>
              <Btn kind="danger" size="sm">Delete account</Btn>
            </div>
          </div>
        </DSSection>

        <DSSection title="Motion">
          <div style={{ fontSize: 13, color: T.inkSoft, lineHeight: 1.6 }}>
            <Row k="Transitions" v="200–250ms · ease-out"/>
            <Row k="Springs" v="None"/>
            <Row k="Loading" v="Skeletons matching content shape"/>
            <Row k="Bounces" v="Never"/>
          </div>
        </DSSection>

        <DSSection title="What this is not">
          <div style={{ fontFamily: T.serif, fontSize: 14, color: T.inkSoft, lineHeight: 1.65, fontStyle:'italic' }}>
            Not a dating app. Not a social network. Not a forum. Not a wellness coach.<br/>A quiet room with good lighting.
          </div>
        </DSSection>
      </div>
    </div>
  );
}

function DSSection({ title, children }) {
  return (
    <div style={{ marginBottom: 36 }}>
      <div style={{ fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.4, textTransform:'uppercase', marginBottom: 14 }}>{title}</div>
      {children}
    </div>
  );
}

function Sw({ name, hex, bg, ink, note }) {
  return (
    <div style={{ background: bg, color: ink, padding: '14px 14px 12px', borderRadius: 4, border: bg === T.bg || bg === T.paper ? `1px solid ${T.hairline}` : 'none', height: 78, display:'flex', flexDirection:'column', justifyContent:'space-between' }}>
      <div style={{ fontFamily: T.sans, fontSize: 13, fontWeight: 500 }}>{name}</div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end' }}>
        <span style={{ fontFamily: T.mono, fontSize: 10.5, opacity: 0.7 }}>{hex}</span>
        <span style={{ fontFamily: T.sans, fontSize: 10.5, opacity: 0.6 }}>{note}</span>
      </div>
    </div>
  );
}

function TypeRow({ font, weight, size, sample, name }) {
  return (
    <div style={{ borderBottom: `1px solid ${T.hairline}`, padding: '10px 0' }}>
      <div style={{ fontFamily: T.mono, fontSize: 10, color: T.inkMute, letterSpacing: 0.5, marginBottom: 4 }}>{name}</div>
      <div style={{ fontFamily: font, fontWeight: weight, fontSize: size, color: T.ink, lineHeight: 1.2, letterSpacing: -0.2 }}>{sample}</div>
    </div>
  );
}

function Row({ k, v }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', borderBottom: `1px solid ${T.hairline}`, padding: '8px 0', fontSize: 13 }}>
      <span style={{ color: T.inkMute }}>{k}</span>
      <span style={{ color: T.ink, fontFamily: T.mono, fontSize: 12 }}>{v}</span>
    </div>
  );
}

window.DSPage = DSPage;
