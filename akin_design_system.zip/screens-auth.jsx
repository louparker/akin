// Akin — Onboarding & Auth screens
const { T, Ico, Btn, TopBar } = window;

function ScreenWelcome() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ flex:1, padding: '120px 32px 0', display:'flex', flexDirection:'column' }}>
        <div style={{ fontFamily: T.mono, fontSize: 11, color: T.inkMute, letterSpacing: 2, textTransform:'uppercase', marginBottom: 28 }}>Akin</div>
        <div style={{ fontFamily: T.serif, fontSize: 44, lineHeight: 1.05, letterSpacing: -0.8, color: T.ink, marginBottom: 20 }}>
          A quieter place<br/>to talk about<br/>dating.
        </div>
        <div style={{ fontFamily: T.sans, fontSize: 16, lineHeight: 1.55, color: T.inkSoft, maxWidth: 290 }}>
          Small, anonymous conversations capped at four people. No swiping, no profiles, no names attached.
        </div>
      </div>
      <div style={{ padding: '0 24px 48px', display:'flex', flexDirection:'column', gap: 12 }}>
        <Btn kind="primary" size="lg" full>Make an account</Btn>
        <Btn kind="ghost" size="md" full>I already have one</Btn>
        <div style={{ textAlign:'center', fontFamily: T.sans, fontSize: 11.5, color: T.inkFaint, marginTop: 8, lineHeight: 1.5 }}>
          By continuing you agree to our <span style={{ textDecoration:'underline', color: T.inkMute }}>Terms</span> and <span style={{ textDecoration:'underline', color: T.inkMute }}>Privacy Policy</span>.
        </div>
      </div>
    </div>
  );
}

function ScreenSignup() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left={Ico.back(20)} title=""/>
      <div style={{ flex:1, padding: '20px 28px 24px', overflow:'auto' }}>
        <div style={{ fontFamily: T.serif, fontSize: 30, lineHeight: 1.1, letterSpacing: -0.5, color: T.ink, marginBottom: 8 }}>Make an account</div>
        <div style={{ fontFamily: T.sans, fontSize: 14, color: T.inkMute, marginBottom: 32, lineHeight: 1.5 }}>Email is private. Used only for sign-in and account recovery.</div>

        <Field label="Email" value="iris.linde@protonmail.com"/>
        <Field label="Password" value="••••••••••••" hint="At least 8 characters."/>

        <div style={{ marginTop: 28, padding: '16px 18px', border: `1px solid ${T.hairline}`, borderRadius: 4, background: T.surface }}>
          <div style={{ display:'flex', alignItems:'flex-start', gap: 12 }}>
            <div style={{ width: 18, height: 18, borderRadius: 3, border: `1.5px solid ${T.ink}`, background: T.ink, flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center', marginTop: 1 }}>
              {Ico.check(12, T.bg)}
            </div>
            <div>
              <div style={{ fontFamily: T.sans, fontSize: 14, fontWeight: 500, color: T.ink, marginBottom: 4 }}>I am 18 or older.</div>
              <div style={{ fontFamily: T.sans, fontSize: 12.5, color: T.inkMute, lineHeight: 1.5 }}>Akin is for adults. We don't ask for ID; we trust you to confirm.</div>
            </div>
          </div>
        </div>
      </div>
      <div style={{ padding: '0 24px 36px' }}>
        <Btn kind="primary" size="lg" full>Continue</Btn>
      </div>
    </div>
  );
}

function ScreenIdentifier() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ flex:1, padding: '100px 32px 40px', display:'flex', flexDirection:'column', justifyContent:'center' }}>
        <div style={{ fontFamily: T.mono, fontSize: 11, color: T.inkMute, letterSpacing: 1.5, textTransform:'uppercase', marginBottom: 24 }}>This is who you'll be here</div>
        <div style={{
          fontFamily: T.serif, fontSize: 52, lineHeight: 1.05, letterSpacing: -1, color: T.ink, marginBottom: 24,
        }}>AmberLark<span style={{ color: T.teal }}>82</span></div>
        <div style={{ fontFamily: T.sans, fontSize: 15, lineHeight: 1.55, color: T.inkSoft, marginBottom: 36, maxWidth: 310 }}>
          Everyone gets one of these. It stays the same so people you talk with can recognise you across conversations. It can't be changed later, and it can't be linked back to your email.
        </div>
        <div style={{ borderTop: `1px solid ${T.hairline}`, paddingTop: 18 }}>
          <div style={{ fontFamily: T.sans, fontSize: 13, color: T.inkMute, lineHeight: 1.55 }}>
            Other people you'll meet here:<br/>
            <span style={{ fontFamily: T.mono, color: T.inkSoft }}>QuietRiver14 · CedarOwl33 · PlumOrchard07</span>
          </div>
        </div>
      </div>
      <div style={{ padding: '0 24px 36px', display:'flex', flexDirection:'column', gap: 10 }}>
        <Btn kind="primary" size="lg" full>This is me</Btn>
        <Btn kind="ghost" size="sm" full>Try another one</Btn>
      </div>
    </div>
  );
}

function ScreenLogin() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left={Ico.back(20)} title=""/>
      <div style={{ flex:1, padding: '60px 28px 24px' }}>
        <div style={{ fontFamily: T.serif, fontSize: 30, lineHeight: 1.1, letterSpacing: -0.5, color: T.ink, marginBottom: 32 }}>Welcome back</div>
        <Field label="Email" value="iris.linde@protonmail.com"/>
        <Field label="Password" value="••••••••••••"/>
        <div style={{ textAlign:'right', marginTop: -8, marginBottom: 28 }}>
          <span style={{ fontFamily: T.sans, fontSize: 13, color: T.teal, textDecoration:'underline' }}>Forgot password</span>
        </div>
        <Btn kind="primary" size="lg" full>Sign in</Btn>
      </div>
    </div>
  );
}

function Field({ label, value, hint }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <div style={{ fontFamily: T.sans, fontSize: 12, fontWeight: 500, color: T.inkMute, marginBottom: 6, letterSpacing: 0.2, textTransform:'uppercase' }}>{label}</div>
      <div style={{
        fontFamily: T.sans, fontSize: 16, color: T.ink,
        padding: '14px 16px',
        background: T.paper,
        border: `1px solid ${T.divider}`,
        borderRadius: 4,
      }}>{value}</div>
      {hint && <div style={{ fontFamily: T.sans, fontSize: 12, color: T.inkFaint, marginTop: 6 }}>{hint}</div>}
    </div>
  );
}

Object.assign(window, { ScreenWelcome, ScreenSignup, ScreenIdentifier, ScreenLogin });
