// Akin — Create post + composer + guidelines
const { T, Ico, Btn, TopBar, CategoryTag, CATEGORIES } = window;

function ScreenCreatePost() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar
        left={<span style={{ fontFamily: T.sans, fontSize: 15, color: T.inkMute }}>Cancel</span>}
        title=""
        right={<span style={{ fontFamily: T.sans, fontSize: 15, fontWeight: 500, color: T.ink }}>Post</span>}
      />
      <div style={{ flex:1, overflow:'auto', padding: '4px 22px 12px' }}>
        <div style={{ padding: '14px 0', borderBottom: `1px solid ${T.hairline}`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div>
            <div style={{ fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase', marginBottom: 4 }}>Category</div>
            <div style={{ fontFamily: T.serif, fontSize: 18, color: T.ink, letterSpacing: -0.2 }}>Vent Space</div>
          </div>
          <span style={{ color: T.inkFaint }}>{Ico.chev(14)}</span>
        </div>

        <div style={{ paddingTop: 18 }}>
          <div style={{
            fontFamily: T.serif, fontSize: 26, lineHeight: 1.25, letterSpacing: -0.3, color: T.ink,
            outline:'none', minHeight: 36, marginBottom: 14,
          }}>He texted "wyd" at 11pm.</div>
          <div style={{
            fontFamily: T.sans, fontSize: 15.5, lineHeight: 1.6, color: T.inkSoft,
            minHeight: 200, outline:'none',
          }}>
            Three weeks of "good morning beautiful" and now wyd at 11pm. I'm not even mad about the obvious thing. I'm mad that I felt it shift before he sent it. Like I knew. And I still answered<span style={{ borderRight: `1.5px solid ${T.ink}`, marginLeft: 1 }}>&nbsp;</span>
          </div>
        </div>
      </div>

      <div style={{ borderTop: `1px solid ${T.hairline}`, padding: '12px 22px', background: T.surface }}>
        <div style={{ fontFamily: T.sans, fontSize: 12, color: T.inkMute, lineHeight: 1.55 }}>
          Posting as <span style={{ fontFamily: T.mono, color: T.inkSoft }}>AmberLark82</span>. Three other people can join this conversation. After that it stays open for the four of you.
        </div>
        <div style={{ display:'flex', justifyContent:'space-between', marginTop: 8, fontFamily: T.mono, fontSize: 11, color: T.inkFaint, letterSpacing: 0.4 }}>
          <span>Title 24 / 150</span><span>Body 187 / 2000</span>
        </div>
      </div>
    </div>
  );
}

function ScreenCategoryPicker() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left={Ico.back(20)} title="Pick a category"/>
      <div style={{ flex:1, overflow:'auto' }}>
        {CATEGORIES.map((c, i) => (
          <div key={c.id} style={{
            padding: '16px 22px',
            borderBottom: i === CATEGORIES.length-1 ? 'none' : `1px solid ${T.hairline}`,
            background: i === 0 ? T.surface : 'transparent',
            display:'flex', alignItems:'flex-start', gap: 14,
          }}>
            <div style={{ flex:1 }}>
              <div style={{ fontFamily: T.serif, fontSize: 17, color: T.ink, letterSpacing: -0.2, marginBottom: 3 }}>{c.name}</div>
              <div style={{ fontFamily: T.sans, fontSize: 13, color: T.inkMute, lineHeight: 1.45 }}>{c.desc}</div>
            </div>
            {i === 0 && <span style={{ color: T.ink, marginTop: 4 }}>{Ico.check(16)}</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

function ScreenGuidelines() {
  return (
    <div style={{ width: 390, height: 844, background: 'rgba(35,31,33,0.55)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ flex:1 }}/>
      <div style={{ background: T.bg, borderRadius: '20px 20px 0 0', padding: '24px 28px 36px' }}>
        <div style={{ width: 36, height: 4, background: T.divider, borderRadius: 2, margin: '-8px auto 22px' }}/>
        <div style={{ fontFamily: T.serif, fontSize: 24, lineHeight: 1.2, letterSpacing: -0.3, color: T.ink, marginBottom: 18 }}>
          Before you post.
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap: 14, marginBottom: 24 }}>
          {[
            ["Speak for yourself.", "First-person stories land best. Generalisations about whole genders or groups don't."],
            ["Stay anonymous, both ways.", "Don't share names, handles, or anything that could identify someone you're talking about."],
            ["Disagree like a human.", "You can push back. You can't be cruel. The cap means whoever joins is sticking around."],
          ].map(([h,b],i)=>(
            <div key={i}>
              <div style={{ fontFamily: T.sans, fontSize: 14.5, fontWeight: 500, color: T.ink, marginBottom: 4 }}>{h}</div>
              <div style={{ fontFamily: T.sans, fontSize: 13.5, color: T.inkSoft, lineHeight: 1.5 }}>{b}</div>
            </div>
          ))}
        </div>
        <Btn kind="primary" size="lg" full>Continue</Btn>
        <div style={{ textAlign:'center', marginTop: 14, fontFamily: T.sans, fontSize: 12, color: T.inkFaint }}>
          Read the full guidelines
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ScreenCreatePost, ScreenCategoryPicker, ScreenGuidelines });
