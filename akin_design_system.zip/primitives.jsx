// Akin — shared UI primitives
const { T } = window;

// Hairline icon set — 1.5px stroke, rounded caps, calm
const Ico = {
  back:    (s=20,c='currentColor') => <svg width={s} height={s} viewBox="0 0 20 20" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 4l-6 6 6 6"/></svg>,
  close:   (s=20,c='currentColor') => <svg width={s} height={s} viewBox="0 0 20 20" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round"><path d="M5 5l10 10M15 5L5 15"/></svg>,
  plus:    (s=20,c='currentColor') => <svg width={s} height={s} viewBox="0 0 20 20" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round"><path d="M10 4v12M4 10h12"/></svg>,
  feed:    (s=22,c='currentColor') => <svg width={s} height={s} viewBox="0 0 22 22" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round"><path d="M4 6h14M4 11h14M4 16h9"/></svg>,
  grid:    (s=22,c='currentColor') => <svg width={s} height={s} viewBox="0 0 22 22" fill="none" stroke={c} strokeWidth="1.5"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="12" y="4" width="6" height="6" rx="1"/><rect x="4" y="12" width="6" height="6" rx="1"/><rect x="12" y="12" width="6" height="6" rx="1"/></svg>,
  pencil:  (s=22,c='currentColor') => <svg width={s} height={s} viewBox="0 0 22 22" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M14 4l4 4-9 9-5 1 1-5z"/></svg>,
  user:    (s=22,c='currentColor') => <svg width={s} height={s} viewBox="0 0 22 22" fill="none" stroke={c} strokeWidth="1.5"><circle cx="11" cy="8" r="3.5"/><path d="M4 19c1.5-3.5 4-5 7-5s5.5 1.5 7 5" strokeLinecap="round"/></svg>,
  flame:   (s=14,c='currentColor',f='none') => <svg width={s} height={s} viewBox="0 0 14 16" fill={f} stroke={c} strokeWidth="1.3" strokeLinejoin="round"><path d="M7 1.5c.5 2 2.5 3 2.5 5.5 0 1.2-.5 2-1.2 2.4.4-.6.4-1.6 0-2.2-.4-.6-1-.8-1.3-1.5-.4 1-1.4 1.6-1.4 3 0 .9.4 1.6 1 2-.7-.2-2.5-1.4-2.5-3.8C4.1 4.6 6.5 4 7 1.5z"/></svg>,
  filter:  (s=18,c='currentColor') => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round"><path d="M3 4h12M5 9h8M7 14h4"/></svg>,
  sort:    (s=18,c='currentColor') => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 3v12M5 15l-2.5-2.5M5 15l2.5-2.5M13 15V3M13 3l-2.5 2.5M13 3l2.5 2.5"/></svg>,
  chev:    (s=14,c='currentColor') => <svg width={s} height={s} viewBox="0 0 14 14" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round"><path d="M5 3l4 4-4 4"/></svg>,
  chevDown:(s=14,c='currentColor') => <svg width={s} height={s} viewBox="0 0 14 14" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round"><path d="M3 5l4 4 4-4"/></svg>,
  more:    (s=20,c='currentColor') => <svg width={s} height={s} viewBox="0 0 20 20" fill={c}><circle cx="4" cy="10" r="1.4"/><circle cx="10" cy="10" r="1.4"/><circle cx="16" cy="10" r="1.4"/></svg>,
  send:    (s=20,c='currentColor') => <svg width={s} height={s} viewBox="0 0 20 20" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 10l14-7-5 16-2.5-7z"/></svg>,
  check:   (s=16,c='currentColor') => <svg width={s} height={s} viewBox="0 0 16 16" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 8l3 3 7-7"/></svg>,
  flag:    (s=18,c='currentColor') => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 16V3M4 4h9l-2 3 2 3H4"/></svg>,
  block:   (s=18,c='currentColor') => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.5"><circle cx="9" cy="9" r="6.5"/><path d="M4.5 4.5l9 9" strokeLinecap="round"/></svg>,
  lock:    (s=18,c='currentColor') => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="8" width="10" height="7" rx="1.5"/><path d="M6 8V6a3 3 0 016 0v2"/></svg>,
  mail:    (s=18,c='currentColor') => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.5" strokeLinejoin="round"><rect x="2.5" y="4" width="13" height="10" rx="1.5"/><path d="M3 5l6 5 6-5"/></svg>,
  dot:     (s=4,c='currentColor') => <svg width={s} height={s} viewBox="0 0 4 4"><circle cx="2" cy="2" r="2" fill={c}/></svg>,
};

// Spice flames — 1..5 with optional dim trailing
function Spice({ level = 0, max = 5, size = 12, color }) {
  const c = color || T.rust;
  return (
    <span style={{ display:'inline-flex', gap: 2, alignItems:'center' }}>
      {Array.from({length:max}).map((_,i)=> (
        <span key={i} style={{ color: i<level ? c : T.inkFaint, opacity: i<level ? 1 : 0.35, display:'inline-flex' }}>
          {Ico.flame(size, 'currentColor', i<level ? c : 'none')}
        </span>
      ))}
    </span>
  );
}

// Anonymous identifier chip — warm, not clinical
function Ident({ name, you = false, size = 'sm' }) {
  const fontSize = size === 'lg' ? 14 : 12.5;
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap: 6,
      fontFamily: T.mono, fontSize, color: you ? T.blue : T.inkSoft,
      letterSpacing: 0.1,
    }}>
      <span style={{
        width: 6, height: 6, borderRadius: 1,
        background: you ? T.blue : T.tealSoft, opacity: you ? 1 : 0.7,
      }}/>
      {name}{you && <span style={{ color: T.inkFaint, fontFamily: T.sans, fontSize: 11 }}>(you)</span>}
    </span>
  );
}

// Category pill — no color tagging by category to keep brand promise
function CategoryTag({ name, muted = false }) {
  return (
    <span style={{
      fontFamily: T.sans, fontSize: 11.5, fontWeight: 500,
      color: muted ? T.inkMute : T.teal,
      letterSpacing: 0.3, textTransform: 'uppercase',
    }}>{name}</span>
  );
}

// Capacity dots — visualize the 4-person cap (1 OP + 3 commenters)
function Capacity({ filled = 1, total = 4, size = 6 }) {
  return (
    <span style={{ display:'inline-flex', gap: 4, alignItems:'center' }}>
      {Array.from({length: total}).map((_,i) => (
        <span key={i} style={{
          width: size, height: size, borderRadius: size/2,
          background: i < filled ? T.teal : 'transparent',
          border: i < filled ? 'none' : `1px solid ${T.divider}`,
        }}/>
      ))}
    </span>
  );
}

// Standard button — restrained, ink-on-bone
function Btn({ children, kind = 'primary', size = 'md', full, onClick, style }) {
  const sizes = { sm:{h:36, p:'0 14px', fs:14}, md:{h:48, p:'0 20px', fs:15}, lg:{h:54, p:'0 24px', fs:16} };
  const s = sizes[size];
  const k = {
    primary:  { background: T.ink, color: T.bg, border: 'none' },
    secondary:{ background: 'transparent', color: T.ink, border: `1px solid ${T.ink}` },
    ghost:    { background: 'transparent', color: T.inkSoft, border: 'none' },
    danger:   { background: 'transparent', color: T.rust, border: `1px solid ${T.rust}` },
  }[kind];
  return (
    <button onClick={onClick} style={{
      height: s.h, padding: s.p, fontSize: s.fs, fontFamily: T.sans, fontWeight: 500,
      letterSpacing: -0.1, borderRadius: 4, cursor:'pointer',
      width: full ? '100%' : undefined,
      transition: 'opacity .2s ease',
      ...k, ...style,
    }}>{children}</button>
  );
}

// Bottom tab bar — 3 items only (Read, Write, You)
function TabBar({ active = 'read' }) {
  const items = [
    { id:'read',  label:'Read',  icon: Ico.feed },
    { id:'write', label:'Write', icon: Ico.pencil },
    { id:'you',   label:'You',   icon: Ico.user },
  ];
  return (
    <div style={{
      borderTop: `1px solid ${T.hairline}`,
      background: T.bg,
      padding: '8px 0 28px',
      display:'flex',
    }}>
      {items.map(it => (
        <div key={it.id} style={{
          flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
          color: active === it.id ? T.ink : T.inkFaint,
        }}>
          {it.icon(22)}
          <span style={{ fontFamily: T.sans, fontSize: 11, fontWeight: active === it.id ? 600 : 400, letterSpacing: 0.1 }}>{it.label}</span>
        </div>
      ))}
    </div>
  );
}

// Top bar
function TopBar({ left, title, right, bordered = true, serif = false }) {
  return (
    <div style={{
      height: 52, display:'flex', alignItems:'center',
      borderBottom: bordered ? `1px solid ${T.hairline}` : 'none',
      padding: '0 8px',
    }}>
      <div style={{ width: 56, display:'flex', justifyContent:'flex-start', paddingLeft: 8, color: T.inkSoft }}>{left}</div>
      <div style={{
        flex:1, textAlign:'center',
        fontFamily: serif ? T.serif : T.sans,
        fontSize: serif ? 22 : 16, fontWeight: serif ? 400 : 500,
        color: T.ink, letterSpacing: serif ? -0.2 : -0.1,
      }}>{title}</div>
      <div style={{ width: 56, display:'flex', justifyContent:'flex-end', paddingRight: 8, color: T.inkSoft }}>{right}</div>
    </div>
  );
}

// Post card (feed item)
function PostCard({ post, last }) {
  return (
    <div style={{
      padding: '20px 22px',
      borderBottom: last ? 'none' : `1px solid ${T.hairline}`,
      background: 'transparent',
    }}>
      <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 10 }}>
        <CategoryTag name={post.category} />
        <span style={{ color: T.inkFaint }}>{Ico.dot(3)}</span>
        <span style={{ fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>{post.time}</span>
      </div>
      <div style={{
        fontFamily: T.serif, fontSize: 19, fontWeight: 400,
        color: T.ink, lineHeight: 1.3, letterSpacing: -0.2, marginBottom: 8,
        textWrap: 'pretty',
      }}>{post.title}</div>
      <div style={{
        fontFamily: T.sans, fontSize: 14, color: T.inkSoft, lineHeight: 1.5,
        marginBottom: 14, textWrap: 'pretty',
        display:'-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient:'vertical', overflow:'hidden',
      }}>{post.excerpt}</div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <Ident name={post.op} />
        <div style={{ display:'flex', alignItems:'center', gap: 14, fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>
          <span style={{ display:'inline-flex', alignItems:'center', gap: 6 }}>
            <Capacity filled={post.participants} total={4}/>
            <span>{post.participants}/4</span>
          </span>
          {post.spice > 0 && <Spice level={post.spice} size={11}/>}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Ico, Spice, Ident, CategoryTag, Capacity, Btn, TabBar, TopBar, PostCard });
