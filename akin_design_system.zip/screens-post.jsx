// Akin — Post detail, commenting, limits
const { T, Ico, Spice, Ident, CategoryTag, Capacity, Btn, TopBar, COMMENTS } = window;

function ScreenPostDetail() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left={Ico.back(20)} right={Ico.more(20)} title=""/>
      <div style={{ flex:1, overflow:'auto' }}>
        <div style={{ padding: '8px 22px 22px', borderBottom: `1px solid ${T.hairline}` }}>
          <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 14 }}>
            <CategoryTag name="VENT SPACE"/>
            <span style={{ color: T.inkFaint }}>{Ico.dot(3)}</span>
            <span style={{ fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>12 min ago</span>
          </div>
          <div style={{ fontFamily: T.serif, fontSize: 24, fontWeight: 400, lineHeight: 1.25, letterSpacing: -0.3, color: T.ink, marginBottom: 14 }}>
            He texted "wyd" at 11pm. Three weeks of "good morning beautiful" and now wyd at 11pm.
          </div>
          <div style={{ fontFamily: T.sans, fontSize: 15, lineHeight: 1.6, color: T.inkSoft, marginBottom: 18 }}>
            I'm not even mad about the obvious thing. I'm mad that I felt it shift before he sent it. Like I knew. And I still answered the first round of texts like everything was fine because I wanted to be wrong.
          </div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <Ident name="AmberLark82"/>
            <div style={{ display:'flex', alignItems:'center', gap: 6, fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>
              <Capacity filled={3}/><span>3/4</span>
            </div>
          </div>
        </div>

        <div style={{ padding: '18px 22px 14px', borderBottom: `1px solid ${T.hairline}`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div>
            <div style={{ fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase', marginBottom: 6 }}>Spice level</div>
            <Spice level={4} size={16}/>
          </div>
          <div style={{ fontFamily: T.sans, fontSize: 12, color: T.inkMute, textAlign:'right' }}>
            <div>4.0 average</div>
            <div style={{ marginTop: 2 }}>17 votes</div>
          </div>
        </div>

        <div style={{ padding: '18px 22px 8px' }}>
          <div style={{ fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase' }}>3 replies</div>
        </div>

        {COMMENTS.map((c, i) => (
          <div key={c.id} style={{ padding: '14px 22px 18px', borderTop: `1px solid ${T.hairline}` }}>
            <div style={{ display:'flex', alignItems:'center', gap: 10, marginBottom: 8 }}>
              <Ident name={c.author} you={c.isOp && false}/>
              {c.isOp && <span style={{ fontFamily: T.sans, fontSize: 10.5, color: T.teal, letterSpacing: 0.4, textTransform:'uppercase', fontWeight: 500 }}>OP</span>}
              <span style={{ flex:1 }}/>
              <span style={{ fontFamily: T.sans, fontSize: 12, color: T.inkFaint }}>{c.time}</span>
            </div>
            <div style={{ fontFamily: T.sans, fontSize: 14.5, lineHeight: 1.55, color: T.inkSoft }}>{c.text}</div>
          </div>
        ))}
        <div style={{ height: 80 }}/>
      </div>

      <div style={{ borderTop: `1px solid ${T.hairline}`, padding: '12px 16px 28px', background: T.bg, display:'flex', alignItems:'center', gap: 10 }}>
        <div style={{
          flex:1, background: T.paper, border: `1px solid ${T.divider}`, borderRadius: 22,
          padding: '10px 16px', fontFamily: T.sans, fontSize: 14.5, color: T.inkFaint,
        }}>Reply to this conversation…</div>
        <div style={{
          width: 40, height: 40, borderRadius: 20, background: T.ink,
          display:'flex', alignItems:'center', justifyContent:'center', color: T.bg,
        }}>{Ico.send(18, T.bg)}</div>
      </div>
    </div>
  );
}

function ScreenLimitFull() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left={Ico.back(20)} right={Ico.more(20)} title=""/>
      <div style={{ flex:1, overflow:'auto' }}>
        <div style={{ padding: '8px 22px 22px', borderBottom: `1px solid ${T.hairline}` }}>
          <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 14 }}>
            <CategoryTag name="DECODE THIS"/>
            <span style={{ color: T.inkFaint }}>{Ico.dot(3)}</span>
            <span style={{ fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>1 hr ago</span>
          </div>
          <div style={{ fontFamily: T.serif, fontSize: 22, fontWeight: 400, lineHeight: 1.25, letterSpacing: -0.3, color: T.ink, marginBottom: 14 }}>
            "I'm not really looking for anything serious right now but you're different"
          </div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <Ident name="PlumOrchard07"/>
            <div style={{ display:'flex', alignItems:'center', gap: 6, fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>
              <Capacity filled={4}/><span>4/4 · full</span>
            </div>
          </div>
        </div>
        <div style={{ padding: '18px 22px', display:'flex', flexDirection:'column', gap: 14 }}>
          {[1,2,3].map(n => (
            <div key={n} style={{ padding: '12px 0', borderBottom: n===3 ? 'none' : `1px solid ${T.hairline}` }}>
              <div style={{ height: 12, width: '40%', background: T.divider, borderRadius: 2, marginBottom: 10 }}/>
              <div style={{ height: 10, width: '100%', background: T.divider, borderRadius: 2, marginBottom: 6, opacity: 0.6 }}/>
              <div style={{ height: 10, width: '85%', background: T.divider, borderRadius: 2, opacity: 0.6 }}/>
            </div>
          ))}
        </div>
      </div>
      <div style={{ borderTop: `1px solid ${T.hairline}`, padding: '18px 22px 30px', background: T.surface }}>
        <div style={{ display:'flex', alignItems:'center', gap: 10, marginBottom: 6 }}>
          <span style={{ color: T.inkMute }}>{Ico.lock(16)}</span>
          <div style={{ fontFamily: T.sans, fontSize: 13.5, fontWeight: 500, color: T.ink }}>This conversation is full.</div>
        </div>
        <div style={{ fontFamily: T.sans, fontSize: 13, color: T.inkMute, lineHeight: 1.5 }}>
          Four people are already talking. You can keep reading — just not joining this one. The cap is what keeps it small.
        </div>
      </div>
    </div>
  );
}

function ScreenLimitActive() {
  return (
    <div style={{ width: 390, height: 844, background: 'rgba(35,31,33,0.55)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ flex:1 }}/>
      <div style={{ background: T.bg, borderRadius: '20px 20px 0 0', padding: '24px 28px 36px' }}>
        <div style={{ width: 36, height: 4, background: T.divider, borderRadius: 2, margin: '-8px auto 22px' }}/>
        <div style={{ fontFamily: T.serif, fontSize: 24, lineHeight: 1.2, letterSpacing: -0.3, color: T.ink, marginBottom: 12 }}>
          You're in three conversations already.
        </div>
        <div style={{ fontFamily: T.sans, fontSize: 14.5, color: T.inkSoft, lineHeight: 1.55, marginBottom: 22 }}>
          Conclude one to join another. A conversation concludes on its own once it reaches four people.
        </div>
        <div style={{ borderTop: `1px solid ${T.hairline}` }}>
          {[
            { t:"Third date ended at her door…", c: 'IS THIS NORMAL', cap: 2 },
            { t:"The man brought a printed list of his five-year goals…", c:'STORY TIME', cap: 3 },
            { t:"If you've been single 6+ years…", c:'HYPOTHETICALLY', cap: 4 },
          ].map((x,i) => (
            <div key={i} style={{ padding: '14px 0', borderBottom: `1px solid ${T.hairline}`, display:'flex', alignItems:'center', gap: 12 }}>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily: T.sans, fontSize: 11, color: T.inkMute, letterSpacing: 0.3, textTransform:'uppercase', marginBottom: 4 }}>{x.c}</div>
                <div style={{ fontFamily: T.serif, fontSize: 15, color: T.ink, lineHeight: 1.35, letterSpacing: -0.1 }}>{x.t}</div>
              </div>
              <Capacity filled={x.cap}/>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 20 }}><Btn kind="secondary" size="md" full>Got it</Btn></div>
      </div>
    </div>
  );
}

function ScreenSpiceVote() {
  return (
    <div style={{ width: 390, height: 844, background: 'rgba(35,31,33,0.55)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ flex:1 }}/>
      <div style={{ background: T.bg, borderRadius: '20px 20px 0 0', padding: '24px 28px 36px' }}>
        <div style={{ width: 36, height: 4, background: T.divider, borderRadius: 2, margin: '-8px auto 22px' }}/>
        <div style={{ fontFamily: T.serif, fontSize: 22, lineHeight: 1.2, letterSpacing: -0.3, color: T.ink, marginBottom: 6 }}>
          How spicy was this?
        </div>
        <div style={{ fontFamily: T.sans, fontSize: 13.5, color: T.inkMute, lineHeight: 1.5, marginBottom: 22 }}>
          One vote per post. Helps others find conversations that match their mood.
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap: 4 }}>
          {[
            ['1','Soft','Just thinking out loud.'],
            ['2','Mild','Slight edge.'],
            ['3','Sharp','Cuts a little.'],
            ['4','Hot','Nerve-touching.'],
            ['5','Scorched','Whole thing is on fire.'],
          ].map(([n,label,desc],i) => (
            <div key={n} style={{
              padding: '14px 16px', borderRadius: 4,
              background: i === 3 ? T.surface : 'transparent',
              border: `1px solid ${i === 3 ? T.ink : T.hairline}`,
              display:'flex', alignItems:'center', gap: 14,
            }}>
              <Spice level={parseInt(n)} size={14}/>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily: T.sans, fontSize: 14.5, fontWeight: 500, color: T.ink }}>{label}</div>
                <div style={{ fontFamily: T.sans, fontSize: 12.5, color: T.inkMute }}>{desc}</div>
              </div>
              {i === 3 && <span style={{ color: T.ink }}>{Ico.check(16)}</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ScreenPostDetail, ScreenLimitFull, ScreenLimitActive, ScreenSpiceVote });
