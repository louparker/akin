// Akin — Profile, Settings, T&S
const { T, Ico, Ident, Btn, TopBar, CategoryTag, Capacity, Spice, TabBar, POSTS } = window;

function ScreenProfile() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left="" title="" right={<span style={{ color: T.inkSoft }}>{Ico.more(20)}</span>}/>
      <div style={{ flex:1, overflow:'auto' }}>
        <div style={{ padding: '12px 22px 24px', borderBottom: `1px solid ${T.hairline}` }}>
          <div style={{ fontFamily: T.mono, fontSize: 11, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase', marginBottom: 8 }}>You are</div>
          <div style={{ fontFamily: T.serif, fontSize: 36, lineHeight: 1.05, letterSpacing: -0.6, color: T.ink, marginBottom: 14 }}>
            AmberLark<span style={{ color: T.teal }}>82</span>
          </div>
          <div style={{ display:'flex', gap: 28, fontFamily: T.sans, fontSize: 12.5, color: T.inkMute }}>
            <span><span style={{ fontFamily: T.mono, color: T.inkSoft }}>Mar 2026</span> · joined</span>
            <span><span style={{ fontFamily: T.mono, color: T.inkSoft }}>9</span> posts · <span style={{ fontFamily: T.mono, color: T.inkSoft }}>34</span> replies</span>
          </div>
        </div>

        <div style={{ padding: '20px 22px 8px', borderBottom: `1px solid ${T.hairline}` }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: 8 }}>
            <div style={{ fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase' }}>Active conversations</div>
            <div style={{ fontFamily: T.mono, fontSize: 11, color: T.inkSoft }}>3 / 3</div>
          </div>
          <div style={{ fontFamily: T.sans, fontSize: 12.5, color: T.inkFaint, lineHeight: 1.5, marginBottom: 4 }}>
            Conclude one to join another.
          </div>
        </div>
        {[
          { c:'IS THIS NORMAL', t:"Third date ended at her door…", cap: 2, age: '2h' },
          { c:'STORY TIME',     t:"The man brought a printed list of his five-year goals.", cap: 3, age: '5h' },
          { c:'HYPOTHETICALLY', t:"What changed when it finally happened?", cap: 4, age: '6h' },
        ].map((x,i,a) => (
          <div key={i} style={{ padding: '14px 22px', borderBottom: i === a.length-1 ? `1px solid ${T.hairline}` : `1px solid ${T.hairline}`, display:'flex', gap: 12, alignItems:'flex-start' }}>
            <div style={{ flex:1 }}>
              <div style={{ display:'flex', gap: 8, alignItems:'center', marginBottom: 4 }}>
                <CategoryTag name={x.c}/>
                <span style={{ color: T.inkFaint }}>{Ico.dot(3)}</span>
                <span style={{ fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>{x.age}</span>
              </div>
              <div style={{ fontFamily: T.serif, fontSize: 15.5, color: T.ink, lineHeight: 1.35, letterSpacing: -0.1 }}>{x.t}</div>
            </div>
            <Capacity filled={x.cap}/>
          </div>
        ))}

        <div style={{ padding: '20px 22px 8px' }}>
          <div style={{ fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase' }}>Your posts</div>
        </div>
        {POSTS.slice(0,3).map((p,i) => (
          <div key={p.id} style={{ padding: '14px 22px', borderTop: `1px solid ${T.hairline}` }}>
            <div style={{ display:'flex', gap: 8, alignItems:'center', marginBottom: 4 }}>
              <CategoryTag name={p.category}/>
              <span style={{ color: T.inkFaint }}>{Ico.dot(3)}</span>
              <span style={{ fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>{p.time}</span>
            </div>
            <div style={{ fontFamily: T.serif, fontSize: 16, color: T.ink, lineHeight: 1.3, letterSpacing: -0.2, marginBottom: 8 }}>{p.title}</div>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', fontFamily: T.sans, fontSize: 12, color: T.inkMute }}>
              <span style={{ display:'inline-flex', alignItems:'center', gap: 6 }}><Capacity filled={p.participants}/>{p.participants}/4</span>
              {p.spice > 0 && <Spice level={p.spice} size={11}/>}
            </div>
          </div>
        ))}
      </div>
      <TabBar active="you"/>
    </div>
  );
}

function ScreenSettings() {
  const Group = ({ label, children }) => (
    <>
      <div style={{ padding: '20px 22px 8px', fontFamily: T.mono, fontSize: 10.5, color: T.inkMute, letterSpacing: 1.2, textTransform:'uppercase' }}>{label}</div>
      <div>{children}</div>
    </>
  );
  const Item = ({ k, v, danger, last }) => (
    <div style={{ padding: '14px 22px', borderTop: `1px solid ${T.hairline}`, borderBottom: last ? `1px solid ${T.hairline}` : 'none', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
      <div style={{ fontFamily: T.sans, fontSize: 15, color: danger ? T.rust : T.ink }}>{k}</div>
      <div style={{ display:'flex', alignItems:'center', gap: 8, fontFamily: T.sans, fontSize: 13.5, color: T.inkMute }}>
        {v && <span style={{ fontFamily: v.startsWith('•') || v.includes('@') ? T.mono : T.sans, fontSize: 12.5 }}>{v}</span>}
        {!danger && <span style={{ color: T.inkFaint }}>{Ico.chev(13)}</span>}
      </div>
    </div>
  );
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left={Ico.back(20)} title="Settings"/>
      <div style={{ flex:1, overflow:'auto' }}>
        <Group label="Account">
          <Item k="Email" v="i•••••@protonmail.com"/>
          <Item k="Change password"/>
          <Item k="Identifier" v="AmberLark82" last/>
        </Group>
        <Group label="Trust & Safety">
          <Item k="Blocked people" v="2"/>
          <Item k="Notifications" v="Off" last/>
        </Group>
        <Group label="Legal">
          <Item k="Privacy Policy"/>
          <Item k="Terms of Service"/>
          <Item k="Community Guidelines" last/>
        </Group>
        <Group label="Support">
          <Item k="Send feedback"/>
          <Item k="App version" v="1.0.0 (12)" last/>
        </Group>
        <Group label=" ">
          <Item k="Log out"/>
          <Item k="Delete account" danger last/>
        </Group>
        <div style={{ height: 24 }}/>
      </div>
    </div>
  );
}

function ScreenReport() {
  return (
    <div style={{ width: 390, height: 844, background: 'rgba(35,31,33,0.55)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ flex:1 }}/>
      <div style={{ background: T.bg, borderRadius: '20px 20px 0 0', padding: '24px 28px 36px' }}>
        <div style={{ width: 36, height: 4, background: T.divider, borderRadius: 2, margin: '-8px auto 22px' }}/>
        <div style={{ fontFamily: T.serif, fontSize: 22, lineHeight: 1.2, letterSpacing: -0.3, color: T.ink, marginBottom: 6 }}>Report this comment</div>
        <div style={{ fontFamily: T.sans, fontSize: 13.5, color: T.inkMute, lineHeight: 1.5, marginBottom: 18 }}>
          A real person reads every report. We don't auto-action. Pick the closest reason.
        </div>
        <div>
          {['Harassment or targeting','Identifying someone','Hate or slurs','Sexual content involving minors','Spam or off-topic','Something else'].map((r,i,a) => (
            <div key={r} style={{ padding: '14px 0', borderBottom: i === a.length-1 ? 'none' : `1px solid ${T.hairline}`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <span style={{ fontFamily: T.sans, fontSize: 15, color: T.ink }}>{r}</span>
              <span style={{ width: 18, height: 18, borderRadius: 9, border: `1.5px solid ${i === 2 ? T.ink : T.divider}`, display:'flex', alignItems:'center', justifyContent:'center' }}>
                {i === 2 && <span style={{ width: 8, height: 8, borderRadius: 4, background: T.ink }}/>}
              </span>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 22 }}><Btn kind="primary" size="lg" full>Send report</Btn></div>
      </div>
    </div>
  );
}

function ScreenBlocked() {
  const blocked = [
    { name:'NorthGale71', when:'Blocked Apr 14' },
    { name:'AshenWillow49', when:'Blocked Mar 02' },
  ];
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <TopBar left={Ico.back(20)} title="Blocked people"/>
      <div style={{ flex:1, overflow:'auto' }}>
        <div style={{ padding: '18px 22px 16px', fontFamily: T.sans, fontSize: 13.5, color: T.inkMute, lineHeight: 1.55, borderBottom: `1px solid ${T.hairline}` }}>
          Their posts and replies stay invisible to you. They are not told you blocked them.
        </div>
        {blocked.map((b,i)=> (
          <div key={b.name} style={{ padding: '16px 22px', borderBottom: i === blocked.length-1 ? 'none' : `1px solid ${T.hairline}`, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div>
              <Ident name={b.name}/>
              <div style={{ fontFamily: T.sans, fontSize: 12, color: T.inkFaint, marginTop: 4 }}>{b.when}</div>
            </div>
            <Btn kind="ghost" size="sm">Unblock</Btn>
          </div>
        ))}
      </div>
    </div>
  );
}

function ScreenEmpty() {
  return (
    <div style={{ width: 390, height: 844, background: T.bg, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ padding: '20px 22px 14px', borderBottom: `1px solid ${T.hairline}` }}>
        <div style={{ fontFamily: T.serif, fontSize: 30, lineHeight: 1.1, letterSpacing: -0.5, color: T.ink }}>akin</div>
      </div>
      <div style={{ flex:1, padding: '0 32px', display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center', textAlign:'center' }}>
        <div style={{ fontFamily: T.serif, fontSize: 24, lineHeight: 1.25, letterSpacing: -0.3, color: T.ink, marginBottom: 12, maxWidth: 280 }}>
          Nobody's posted in <em style={{ fontStyle:'italic' }}>Good Vibes Only</em> in the last hour.
        </div>
        <div style={{ fontFamily: T.sans, fontSize: 14, color: T.inkMute, lineHeight: 1.55, marginBottom: 28, maxWidth: 280 }}>
          Try another category, or be the first one tonight.
        </div>
        <Btn kind="secondary" size="md">Start one</Btn>
      </div>
      <TabBar active="read"/>
    </div>
  );
}

Object.assign(window, { ScreenProfile, ScreenSettings, ScreenReport, ScreenBlocked, ScreenEmpty });
